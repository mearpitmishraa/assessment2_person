const express = require('express');
const router = express.Router();
const Person = require('../models/Person');

// GET /person - Display list of people
router.get('/', async (req, res) => {
    try {
        const people = await Person.find();
        res.render('index', { people });
    } catch (error) {
        res.status(500).send(error.message);
    }
});

// GET /person/new - Show form to create new person
router.get('/new', (req, res) => {
    res.render('new');
});

// POST /person - Create new person
router.post('/', async (req, res) => {
    try {
        const person = new Person(req.body);
        await person.save();
        res.redirect('/person');
    } catch (error) {
        res.status(400).render('new', { error: error.message });
    }
});

// GET /person/:id/edit - Show edit form
router.get('/:id/edit', async (req, res) => {
    try {
        const person = await Person.findById(req.params.id);
        res.render('edit', { person });
    } catch (error) {
        res.status(404).send('Person not found');
    }
});

// PUT /person/:id - Update person
router.put('/:id', async (req, res) => {
    try {
        await Person.findByIdAndUpdate(req.params.id, req.body);
        res.redirect('/person');
    } catch (error) {
        res.status(400).render('edit', { error: error.message });
    }
});

// GET /person/:id/delete - Show delete confirmation
router.get('/:id/delete', async (req, res) => {
    try {
        const person = await Person.findById(req.params.id);
        res.render('delete', { person });
    } catch (error) {
        res.status(404).send('Person not found');
    }
});

// DELETE /person/:id - Delete person
router.delete('/:id', async (req, res) => {
    try {
        await Person.findByIdAndDelete(req.params.id);
        res.redirect('/person');
    } catch (error) {
        res.status(500).send(error.message);
    }
});

module.exports = router; 